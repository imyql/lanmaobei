<?php
class orderDetailModel extends baseModel{
	protected $table = 'order_detail';
}