<?php if(!defined('APP_NAME')) exit;?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="__PUBLICAPP__/css/base.css" />
<script type="text/javascript" src="__PUBLIC__/js/jquery1.7.js"></script>
<title>会员中心</title>
</head>
<body>
{include file="$__template_file"}
</body>
</html>