<?php
class methodModel extends baseModel{
	protected $table = 'method';
}