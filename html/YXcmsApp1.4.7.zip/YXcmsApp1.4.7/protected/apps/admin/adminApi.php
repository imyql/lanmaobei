<?php
class adminApi extends baseApi{
	
}